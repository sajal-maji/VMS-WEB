export const environment = {
  production: false,
  apiBaseUrl: 'https://apiservice.videonetics.com:7443/V1/REST/'
};


