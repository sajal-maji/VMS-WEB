export const environment = {
  production: false,
  apiBaseUrl: 'https://172.16.1.182:7443/ivmsweb'
};


