export const environment = {
  production: true,
  apiBaseUrl: 'https://172.16.1.182:7443/ivmsweb'
};


