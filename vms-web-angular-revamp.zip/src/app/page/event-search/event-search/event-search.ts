import { Component } from '@angular/core';

@Component({
  selector: 'app-event-search',
  imports: [],
  templateUrl: './event-search.html',
  styleUrl: './event-search.css'
})
export class EventSearch {

}
