import { Component } from '@angular/core';

@Component({
  selector: 'app-audio-brodcast',
  imports: [],
  templateUrl: './audio-brodcast.html',
  styleUrl: './audio-brodcast.css'
})
export class AudioBrodcast {

}
