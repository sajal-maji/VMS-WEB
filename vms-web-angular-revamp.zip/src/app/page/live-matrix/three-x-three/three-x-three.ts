import { Component } from '@angular/core';

@Component({
  selector: 'app-three-x-three',
  imports: [],
  templateUrl: './three-x-three.html',
  styleUrl: './three-x-three.css'
})
export class ThreeXThree {

}
