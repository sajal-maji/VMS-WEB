import { Component } from '@angular/core';

@Component({
  selector: 'app-four-x-four',
  imports: [],
  templateUrl: './four-x-four.html',
  styleUrl: './four-x-four.css'
})
export class FourXFour {

}
