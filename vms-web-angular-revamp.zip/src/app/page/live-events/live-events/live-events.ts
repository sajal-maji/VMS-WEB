import { Component } from '@angular/core';

@Component({
  selector: 'app-live-events',
  imports: [],
  templateUrl: './live-events.html',
  styleUrl: './live-events.css'
})
export class LiveEvents {

}
