import { Component } from '@angular/core';

@Component({
  selector: 'app-two-x-two',
  imports: [],
  templateUrl: './two-x-two.html',
  styleUrl: './two-x-two.css'
})
export class TwoXTwo {

}
