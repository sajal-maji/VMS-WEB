import { Component } from '@angular/core';

@Component({
  selector: 'app-one-x-one',
  imports: [],
  templateUrl: './one-x-one.html',
  styleUrl: './one-x-one.css'
})
export class OneXOne {

}
